# Example Package

The detailed description of the **Polynomial Regression via Latent Tensor Reconstruction(LTR)** solver is in *ltr_user_guide_10.pdf* which is located in the docs subdirectory, [LTR user guide](docs/ltr_user_guide_10.pdf)   

 